<!DOCTYPE html>
<html lang="en">

<head>

<?php include('lib/dbconnect.php');?>
<?php include('lib/session.php'); ?>
<?php include('php/student_functions.php');?> 
<?php include('layouts/title.php');?>
<?php include('layouts/stylesheet.php'); ?>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        
     <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="addStudentDetails.php">
                <div class="sidebar-brand-icon">
                    <i class="fas fa-home"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Student Management </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item  -->
           
            <!-- Nav Item -  Menu -->
           
             <li class="nav-item active">
                <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true"
                    aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-users"></i>
                    <span>Student</span>
                </a>
                <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                       
                        <a class="collapse-item active" href="addStudentDetails.php">Add Student</a>
                        <a class="collapse-item" href="studentDetails.php">Student Details</a>
                         <a class="collapse-item" href="scores.php">Scores </a>
                    </div>
                </div>
            </li>

<!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
            <!-- nav -->
               <?php include('layouts/header.php');?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    
            <div class="row mb-2">
                  <div class="col-sm-12">
                    <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="">Home</a></li>
                      <li class="breadcrumb-item "><a href="studentDetails.php">Students </a></li>
                        <li class="breadcrumb-item active">Add Student </li>
                    </ol>
                  </div>
            </div>
                   

                    <!-- student details table -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-file"></i>  Add Student Details</h6>
                        </div>
                       
                        <div class="card-body">
                            <!-- form -->
                            <form class="form-horizontal" method="post" action="studentDetails.php" >
                                <div class="form-group row">
                                   <label for="Student Name" class="col-sm-2 col-form-label">Student Name</label>
                                   <div class="col-sm-10">
                                      <input type="text" name="student_name" class="form-control" id="exampleInputRounded0" placeholder="Student Name" value="" required="">
                                    </div>
                                  </div>
                                  <div class="form-group row">
                                      <label for="Date of Birth" class="col-sm-2 col-form-label">Date of Birth</label>
                                    <div class="col-sm-10">
                                      <input type="date" name="date_of_birth" class="form-control" id="exampleInputRounded0" placeholder="Date of Birth" value="" required="">
                                    </div>
                                </div>
                              
                                 <hr class="my-4">
                                    <div class="form-group row"> 
                                      <div class="col-sm-12">
                                        <button type="submit" name="save_student_details" value="" class="btn btn-primary btn-sm btn-block"><i class="fa fa-check-circle"></i> Save Details</button>
                                      </div>
                                    </div>
                            </form>
                            <!-- Form ends -->
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php include('layouts/footer.php');?>
            <!-- End of Footer -->
        </div>

        <!-- End of Content Wrapper -->
    </div>

    <!-- End of Page Wrapper -->
    
  <!-- scripts -->
   <?php include('layouts/script.php');?>
   <!-- scripts ends -->
</body>

</html>