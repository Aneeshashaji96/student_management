// Call the dataTables jQuery plugin
$(document).ready(function() {
  $('#dataTable').DataTable();
});

// $(document).ready(function() {
// $('#dataTable').DataTable({
// 	"dom": '<"top"f>rt<"bottom">i<"mt-2">p'
// });

// // incase table is empty..
// $('.dataTables_empty').css('background','#fff');
// $('.dataTables_empty').html("<div class='alert alert-primary'><i class='fa fa-info-circle'></i> You don't have any bill. Please <b><a class='link' href='addStudentDetails'>add a Student</a></b></div>");
// } );


