<!-- dbconnect -->
<?php 
date_default_timezone_set("Asia/Kolkata");   //India time (GMT+5:30)
$con = mysqli_connect("localhost","root","");
if (!$con) {
die("Connection failed: " . mysqli_connect_error());
}else{
mysqli_select_db($con,"student_management");
}
?>