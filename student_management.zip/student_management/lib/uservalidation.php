<!-- user validation -->
<?php
if (isset($_POST['login'])) {
include('dbconnect.php');
session_start();
$_SESSION['user'] = "";
$password = hash('sha512',$_POST['password']);
$user = mysqli_query($con, "SELECT * FROM `users` WHERE `user_name` = '".$_POST['email']."' AND `password` = '".$password."'");

if (mysqli_num_rows($user) > 0) {
$user = mysqli_fetch_array($user);

$_SESSION['id'] = $user['id'];
$_SESSION['user'] = "user"; 
$_SESSION['name'] = $user['first_name']." ".$user['last_name']; 
$_SESSION['email'] = $user['email']; 
$_SESSION['user_name'] = $user['user_name']; 
header('location:../addStudentDetails');

}
else{
header('location:logout');

}
}
?>