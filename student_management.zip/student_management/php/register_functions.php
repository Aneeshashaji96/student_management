 <!-- onkeyup	 -->
<script>
	function copytousername(email){
	$("#user_name").val(email);
	}
</script>
<?php
	// db connection
	include('lib/dbconnect.php');
	//  user save

	$datetime = date('d-m-Y h:i a');
	if (isset($_POST['user_save'])) {
     $password = hash('sha512',$_POST['password']);
	 $insert_users = mysqli_query($con,"INSERT INTO `users`(`id`,`first_name`, `last_name`, `email`,`user_name`, `password`, `created_on`) VALUES (NULL,'".$_POST['first_name']."','".$_POST['last_name']."','".$_POST['email']."','".$_POST['user_name']."','".$password."' ,'".$datetime."')");

	  if ($insert_users) {
	                     header('location:index.php');
     }

	}
?>