
<script>
	function add_score(id){
	$("#students_id").val(id)
	
	}
</script>




<?php
	// db connection
	include('lib/dbconnect.php');
	// saving student details
	$datetime = date('d-m-Y h:i a');
	if (isset($_POST['save_student_details'])) {
	$insert = mysqli_query($con, "INSERT INTO `students` (`id`,`student_name`,`date_of_birth`,`creator`,`created_on`) VALUES (NULL,'".$_POST['student_name']."','".$_POST['date_of_birth']."','".$_SESSION['name']."','".$datetime."')");
	}

	 // saving scores
	$datetime = date('d-m-Y h:i a');
	if (isset($_POST['add_score'])) {
	$insert_course = mysqli_query($con,"INSERT INTO `scores` (`id`,`students_id`,`course_name`,`score`,`creator`,`created_on`) VALUES (NULL,'".$_POST['students_id']."','".$_POST['course']."','".$_POST['score']."','".$_SESSION['name']."','".$datetime."')");

	}
?>