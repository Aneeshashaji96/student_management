<!DOCTYPE html>
<html lang="en">
<head>

 <?php include('lib/dbconnect.php');?>
 <?php include('lib/session.php'); ?>
   <?php include('php/student_functions.php');?>
    <?php include('layouts/title.php');?>

    <?php include('layouts/stylesheet.php'); ?>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
          <!-- Sidebar -->
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="addStudentDetails.php">
                <div class="sidebar-brand-icon">
                    <i class="fas fa-home"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Student Management </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item  -->
           
            <!-- Nav Item -  Menu -->
           <li class="nav-item active">
                <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true"
                    aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-users"></i>
                    <span>Student</span>
                </a>
                <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                       
                        <a class="collapse-item " href="addStudentDetails.php">Add Student</a>
                        <a class="collapse-item" href="studentDetails.php">Student Details</a>
                        <a class="collapse-item active" href="scores.php">Scores </a>
                    </div>
                </div>
            </li>
<!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
         <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
                     <!-- nav bar -->
                  <?php include('layouts/header.php');?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->

        <div class="row mb-2">
          <div class="col-sm-12">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="">Home</a></li>
                <li class="breadcrumb-item "><a href="studentDetails.php">Students Details </a></li>
              <li class="breadcrumb-item active">Student Scores</li>
            </ol>
          </div>
        </div>
                    
                    <!-- student details table -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"> <i class="fa fa-list-ul"></i>  Student Scores</h6>
                        </div>

                        <div class="card-body">
                            
                            <div class="table-responsive">
                                <table class="table " id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Student Id</th>
                                            <th>Student Name</th>
                                            <th>Date of Birth</th>
                                            <th>Course</th>
                                            <th>Score</th>
                                            
                                        </tr>
                                    </thead>
                                <tbody>
                                    
                                   <?php 
                                    $i=1;
                                    $get_data = mysqli_query($con, "Select s.id,s.student_name,s.date_of_birth,ss.course_name,ss.score from students as s join scores as ss on s.id=ss.students_id ");
                                
                                    
                                    while ($datas = mysqli_fetch_array($get_data)) {
                                        // changing date format
                                      $date_of_birth = $datas['date_of_birth'];
                                      $changedDate = date("d-m-Y", strtotime($date_of_birth));
                                    echo'
                                    <tr>
                                    
                                    <td>'.$datas['id'].'</td>
                                    <td>'.$datas['student_name'].'</td>
                                    <td>'.$changedDate.'</td>
                                    <td>'.$datas['course_name'].'</td>
                                    <td>'.$datas['score'].'</td>
                                    </tr>';
                                  
                                    }

                                    ?>
                                
                                    
                                </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
             <?php include('layouts/footer.php');?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->



     <!-- scripts -->
   <?php include('layouts/script.php');?>
   <!-- scripts ends -->

</body>

</html>