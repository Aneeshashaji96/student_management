<!DOCTYPE html>
<html lang="en">
<head>

 <?php include('lib/dbconnect.php');?>
 <?php include('lib/session.php'); ?>
   <?php include('php/student_functions.php');?>
    <?php include('layouts/title.php');?>

    <?php include('layouts/stylesheet.php'); ?>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">
          <!-- Sidebar -->
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

        <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="addStudentDetails.php">
                <div class="sidebar-brand-icon">
                    <i class="fas fa-home"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Student Management </div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item  -->
           
            <!-- Nav Item -  Menu -->
           <li class="nav-item active">
                <a class="nav-link" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true"
                    aria-controls="collapseTwo">
                    <i class="fas fa-fw fa-users"></i>
                    <span>Student</span>
                </a>
                <div id="collapseTwo" class="collapse show" aria-labelledby="headingTwo"
                    data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                       
                        <a class="collapse-item " href="addStudentDetails.php">Add Student</a>
                        <a class="collapse-item active" href="studentDetails.php">Student Details</a>
                        <a class="collapse-item" href="scores.php">Scores </a>
                    </div>
                </div>
            </li>
<!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
         <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">
                     <!-- nav bar -->
                  <?php include('layouts/header.php');?>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->

        <div class="row mb-2">
          <div class="col-sm-12">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="">Home</a></li>
              <li class="breadcrumb-item active">Student Details</li>
            </ol>
          </div>
        </div>
                    
                    <!-- student details table -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"> <i class="fa fa-list-ul"></i>  Student Details</h6>
                        </div>

                        <div class="card-body">
                            <div align="right">
                              <a href="addStudentDetails.php" class="btn btn-primary btn-sm" ><i class="fa fa-plus"></i> Add Student</a>
                            </div><hr>
                            <div class="table-responsive">
                                <!-- table -->
                                <table class="table " id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Name</th>
                                            <th>Date of Birth</th>
                                            
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                <tbody>
                                    <?php 
                                    $i=1;
                                    $get_student = mysqli_query($con, "SELECT * FROM `students` ");
                                    while ($datas = mysqli_fetch_array($get_student)) {
                                       // changing date format
                                      $date_of_birth = $datas['date_of_birth'];
                                      $changedDate = date("d-m-Y", strtotime($date_of_birth));

                                    echo'
                                    <tr>
                                    <td>'.$datas['id'].'</td>

                                    <td>'.$datas['student_name'].'</td>
                                    <td>'.$changedDate.'</td>
                                    <td><button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#addscoremodal"  title="Add score" onclick=\'add_score("'.$datas['id'].'")\'><i class="fa fa-plus"></i> Add Score</button></td>
                                    </tr>';
                                    $i++;
                                    }

                                    ?>
                                    
                                </tbody>
                                </table>
                                <!-- table ends -->
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
             <?php include('layouts/footer.php');?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->



     <!-- scripts -->
   <?php include('layouts/script.php');?>
   <!-- scripts ends -->
  <!-- Score Modal-->
    <div class="modal fade" id="addscoremodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog " role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Score</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form class="form-horizontal" method="post" action="scores.php" >
                  <div class="modal-body">
                    <input type="hidden" name="students_id" id="students_id" class="form-control" id="exampleInputRounded0" placeholder=""  >
                               <div class="form-group row">
                                   <label for="Course" class="col-sm-2 col-form-label">Course</label>
                                   <div class="col-sm-10">
                                       <select class="form-control form-control-sm " name="course"  required="">
                                         <option value = "">Select</option> 
                                         <option value="Computer Science">Computer Science</option> 
                                         <option value="Mathematics">Mathematics</option>
                                         <option value="Physics">Physics</option> 
                                         
                                      </select>
                                    </div>
                                  </div>
                                   <div class="form-group row">
                                      <label for="Score" class="col-sm-2 col-form-label">Score</label>
                                    <div class="col-sm-10">
                                      <input type="text" name="score" class="form-control" id="exampleInputRounded0" placeholder="Score" value="" required="">
                                    </div>
                                </div> 


                  </div>
                   <div class="modal-footer">
                       <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                       <button class="btn btn-primary" type="submit" name="add_score" >Save</button>
                  </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>